profanity.exe --matching matching.txt --q 1 --h 6
pause